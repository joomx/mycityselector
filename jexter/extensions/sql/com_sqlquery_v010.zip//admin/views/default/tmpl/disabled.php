<?php
/**
 *
 */

echo "Disabled!";