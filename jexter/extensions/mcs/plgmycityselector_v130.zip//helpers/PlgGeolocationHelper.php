<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 30.07.15
 * Time: 11:34
 */

class PlgGeolocationHelper {

} 